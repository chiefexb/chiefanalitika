A simple example for integrating [Persona](https://login.persona.org/) into a
Flask application. In addition to Flask, it requires the
[requests](www.python-requests.org/) library.
