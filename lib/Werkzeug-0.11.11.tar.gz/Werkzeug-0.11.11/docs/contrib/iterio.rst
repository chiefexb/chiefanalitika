=======
Iter IO
=======

.. automodule:: werkzeug.contrib.iterio

.. autoclass:: IterIO
   :members:
