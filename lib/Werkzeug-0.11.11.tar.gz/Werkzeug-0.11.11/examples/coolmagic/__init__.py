# -*- coding: utf-8 -*-
"""
    coolmagic
    ~~~~~~~~~

    Package description goes here.

    :copyright: (c) 2009 by the Werkzeug Team, see AUTHORS for more details.
    :license: BSD, see LICENSE for more details.
"""
from coolmagic.application import make_app
